Downloaded from Kaggle (https://www.kaggle.com/chicago/chicago-food-inspections) the 19/10/2019.
